import pytest
from http import HTTPStatus
from typing import Union, Any, Mapping
from enum import EnumMeta
from functools import partial

from aiohttp.test_utils import TestClient

from phoenix.api.handlers import Question, QuestionParametrized
from phoenix.api.schema import (
    QuestionPostResponseSchema, QuestionGetResponseSchema,
    QuestionViewResponseSchema
)
from phoenix.utils.testing import (
    question_generate, program_generate, age_generate,
    fill_age, fill_program, fill_question, view
)


async def import_question(
    client: TestClient,
    data: Mapping[str, Any],
    expected_status: Union[int, EnumMeta],
    **request_kwargs
) -> Mapping[str, Any]:
    response = await client.post(
        Question.URL_PATH, json=data, **request_kwargs
    )
    assert response.status == expected_status
    if response.status == HTTPStatus.CREATED:
        data = await response.json()
        errors = QuestionPostResponseSchema().validate(data)
        assert errors == {}
        return data


async def test_add_question(api_client, migrated_postgres_connection):
    age_id = fill_age(migrated_postgres_connection, age_generate())
    program_id = fill_program(migrated_postgres_connection, program_generate())
    data = question_generate(
        age_id=age_id,
        program_id=program_id
    )
    result = await import_question(
        api_client,
        data,
        HTTPStatus.CREATED
    )
    for key, value in data.items():
        assert result['data'][key] == value

    # проверка на идемпотентность
    await import_question(
        api_client,
        data,
        HTTPStatus.BAD_REQUEST
    )

    # проверяем, работает ли валидация
    await import_question(
        api_client,
        {},
        HTTPStatus.BAD_REQUEST
    )


async def get_questions(
    client: TestClient,
    expected_status: Union[int, EnumMeta],
    **request_kwargs
) -> Mapping[str, Any]:
    response = await client.get(Question.URL_PATH, **request_kwargs)
    assert response.status == expected_status
    if response.status == HTTPStatus.OK:
        data = await response.json()
        errors = QuestionGetResponseSchema().validate(data)
        assert errors == {}
        return data


@pytest.mark.parametrize('params,expected', (
    ({}, {
        'page': 1,
        'per_page': 10,
        'count': 3,
        'all': 3
    }),
    ({
        'page': 2
     }, {
        'page': 2,
        'per_page': 10,
        'count': 3,
        'all': 0
    }),
    ({
        'per_page': 2,
        'page': 2
     }, {
        'page': 2,
        'per_page': 2,
        'count': 3,
        'all': 1
    })
))
async def test_get_questions(api_client,
                             migrated_postgres_connection,
                             params,
                             expected):
    questions = [question_generate() for _ in range(3)]
    for q in questions:
        fill_question(migrated_postgres_connection, q)
    result = await get_questions(api_client, HTTPStatus.OK, params=params)
    all_ = expected['all']
    del expected['all']
    assert result['data']['_meta'] == expected
    assert len(result['data']['items']) == all_


view_question = partial(
    view,
    view_class=QuestionParametrized,
    response_schema=QuestionViewResponseSchema()
)


async def test_view_question(api_client,
                             migrated_postgres_connection):
    questions = [question_generate() for _ in range(2)]
    for q in questions:
        q['id'] = fill_question(migrated_postgres_connection, q)
    q = questions[1]
    result = await view_question(api_client, q['id'], HTTPStatus.OK)
    for key, value in q.items():
        assert result['data'][key] == value
