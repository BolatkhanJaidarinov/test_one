import pytest
from http import HTTPStatus
from typing import Union, Any, Mapping
from enum import EnumMeta
from functools import partial

from aiohttp.test_utils import TestClient

from phoenix.api.handlers import Program, ProgramParametrized
from phoenix.api.schema import (
    ProgramPostResponseSchema, ProgramGetResponseSchema,
    ProgramViewResponseSchema
)
from phoenix.utils.testing import (
    fill_program, program_generate, view
)


async def import_program(
    client: TestClient,
    data: Mapping[str, Any],
    expected_status: Union[int, EnumMeta],
    **request_kwargs
) -> Mapping[str, Any]:
    response = await client.post(Program.URL_PATH, json=data, **request_kwargs)
    assert response.status == expected_status
    if response.status == HTTPStatus.CREATED:
        data = await response.json()
        errors = ProgramPostResponseSchema().validate(data)
        assert errors == {}
        return data


async def test_add_program(api_client):
    data = program_generate()
    result = await import_program(
        api_client,
        data,
        HTTPStatus.CREATED
    )
    assert result['data']['name'] == data['name']
    assert not result['data']['is_active']

    # проверка на идемпотентность
    await import_program(
        api_client,
        data,
        HTTPStatus.BAD_REQUEST
    )

    # проверяем, работает ли валидация
    await import_program(
        api_client,
        {},
        HTTPStatus.BAD_REQUEST
    )


async def get_ages(
    client: TestClient,
    expected_status: Union[int, EnumMeta],
    **request_kwargs
) -> Mapping[str, Any]:
    response = await client.get(Program.URL_PATH, **request_kwargs)
    assert response.status == expected_status
    if response.status == HTTPStatus.OK:
        data = await response.json()
        errors = ProgramGetResponseSchema().validate(data)
        assert errors == {}
        return data


@pytest.mark.parametrize('params,expected', (
    ({}, {
        'page': 1,
        'per_page': 10,
        'count': 3,
        'all': 3
    }),
    ({
        'page': 2
     }, {
        'page': 2,
        'per_page': 10,
        'count': 3,
        'all': 0
    }),
    ({
        'per_page': 2,
        'page': 2
     }, {
        'page': 2,
        'per_page': 2,
        'count': 3,
        'all': 1
    })
))
async def test_get_programs(api_client,
                            migrated_postgres_connection,
                            params,
                            expected):
    programs = [program_generate() for _ in range(3)]
    for p in programs:
        fill_program(migrated_postgres_connection, p)
    result = await get_ages(api_client, HTTPStatus.OK, params=params)
    all_ = expected['all']
    del expected['all']
    assert result['data']['_meta'] == expected
    assert len(result['data']['items']) == all_


view_program = partial(
    view,
    view_class=ProgramParametrized,
    response_schema=ProgramViewResponseSchema()
)


async def test_view_program(api_client,
                            migrated_postgres_connection):
    programs = [program_generate() for _ in range(2)]
    for p in programs:
        p['id'] = fill_program(migrated_postgres_connection, p)
    p = programs[1]
    result = await view_program(api_client, p['id'], HTTPStatus.OK)
    for key, value in p.items():
        assert result['data'][key] == value
