__author__ = 'Alexey Tulovskiy'
__maintainer__ = __author__

__email__ = 'tulov.alex@gmail.com'
__license__ = 'FSF'
__version__ = '0.0.1'


__all__ = (
    '__author__',
    '__email__',
    '__license__',
    '__maintainer__',
    '__version__',
)
