import faker
from http import HTTPStatus
from random import randint, choice
from enum import EnumMeta

from marshmallow import Schema
from typing import Optional, Dict, Any, Union, Mapping
from aiohttp.web_urldispatcher import DynamicResource
from aiohttp.test_utils import TestClient
from phoenix.db.schema import (
    programs_table, ages_table, QuestionTypes,
    questions_table
)
from phoenix.api.handlers.base import BaseView


fake = faker.Faker('ru_RU')


def url_for(path: str, **kwargs) -> str:
    """
    Генерирует URL для динамического aiohttp маршрута с параметрами.
    """
    kwargs = {
        key: str(value)  # Все значения должны быть str (для DynamicResource)
        for key, value in kwargs.items()
    }
    return str(DynamicResource(path).url_for(**kwargs))


def program_generate(
    *,
    id_: Optional[int] = None,
    is_active: bool = False,
    name: Optional[str] = None
) -> Dict[str, Any]:
    res = {
        'is_active': is_active
    }
    if name is None:
        res['name'] = fake.sentence()
    if id_:
        res['id'] = id_
    return res


def age_generate(
    *,
    id_: Optional[int] = None,
    from_age: Optional[int] = None,
    to_age: Optional[int] = None,
    name: Optional[str] = None
) -> Dict[str, Any]:
    if name is None:
        name = fake.sentence()
    i = randint(0, 100)
    if from_age is None and i < 80:
        from_age = randint(1, 15)
    if to_age is None and 20 < i < 95:
        from_ = from_age or 1
        to_age = randint(from_, 80)
    res = {
        'name': name,
    }
    if from_age:
        res['from_age'] = from_age
    if to_age:
        res['to_age'] = to_age
    if id_:
        res['id'] = id_
    return res


def get_fake_answer(type_: str) -> str:
    if type_ == QuestionTypes.type_text.value:
        return fake.word()
    if type_ == QuestionTypes.some_variants.value:
        i = randint(3, 8)
        return '|'.join(fake.word() for _ in range(i))
    if type_ == QuestionTypes.build_sentence.value:
        return fake.sentence().replace(' ', '|')
    words = fake.sentence().split()
    word = '|'.join(fake.word() for _ in range(3))
    words[0] = f'[{word}]'
    if len(words) > 3:
        word = '|'.join(fake.word() for _ in range(3))
        words[2] = f'[{word}]'
    return ' '.join(words)


def question_generate(
    *,
    program_id: Optional[int] = None,
    age_id: Optional[int] = None,
    id_: Optional[int] = None,
    type_: Optional[str] = None,
    image: Optional[str] = None,
    video: Optional[str] = None,
    audio: Optional[str] = None,
    text: Optional[str] = None,
    answer: Optional[str] = None,
    is_active: bool = False
) -> Dict[str, Any]:
    if type_ is None:
        type_ = choice([t.value for t in QuestionTypes])

    if type_ in [QuestionTypes.type_text.value,
                 QuestionTypes.some_variants.value]:
        if not any((image, video, audio)):
            i = randint(0, 4)
            if i == 1:
                image = fake.image_url()
            elif i == 2:
                audio = fake.uri()
            elif i == 3:
                video = fake.uri()
        if text is None:
            text = fake.sentence()
    if answer is None:
        answer = get_fake_answer(type_)

    res = {
        'type': type_,
        'answer': answer,
        'is_active': is_active
    }
    if image:
        res['image'] = image
    if video:
        res['video'] = video
    if audio:
        res['audio'] = audio
    if text:
        res['text'] = text
    if id_:
        res['id'] = id_
    if program_id:
        res['program_id'] = program_id
    if age_id:
        res['age_id'] = age_id
    return res


def fill_program(conn, program: Dict[str, Any]) -> int:
    res = conn.execute(
        programs_table.insert().values(
            program
        ).returning(
            programs_table.c.id
        )
    )
    for row in res:
        return row['id']


def fill_age(conn, age: Dict[str, Any]) -> int:
    if 'from_age' not in age:
        age['from_age'] = 0
    if 'to_age' not in age:
        age['to_age'] = 100
    res = conn.execute(
        ages_table.insert().values(
            age
        ).returning(
            ages_table.c.id
        )
    )
    for row in res:
        return row['id']


def fill_question(conn, question: Dict[str, Any]) -> int:
    if 'age_id' not in question:
        age = age_generate()
        age_id = fill_age(conn, age)
        question['age_id'] = age_id
    if 'program_id' not in question:
        program = program_generate()
        program_id = fill_program(conn, program)
        question['program_id'] = program_id
    res = conn.execute(
        questions_table.insert().values(
            question
        ).returning(
            questions_table.c.id
        )
    )
    for row in res:
        return row['id']


async def view(
    client: TestClient,
    id_: int,
    expected_status: Union[int, EnumMeta],
    *,
    view_class: BaseView,
    response_schema: Schema,
    **request_kwargs
) -> Mapping[str, Any]:
    response = await client.get(
        url_for(view_class.URL_PATH, id=id_), **request_kwargs)
    assert response.status == expected_status
    if response.status == HTTPStatus.OK:
        data = await response.json()
        errors = response_schema.validate(data)
        assert errors == {}
        return data
