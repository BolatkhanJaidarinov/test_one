from aiohttp.web_urldispatcher import View
from marshmallow import Schema, ValidationError
from asyncpgsa import PG

from phoenix.api.db_service import DBService


GET_QUERY_PARAMS = [
    {
        'in': 'query',
        'name': 'page',
        'schema': {'type': 'integer'},
        'required': False,
        'default': 1
    }, {
        'in': 'query',
        'name': 'per_page',
        'schema': {'type': 'integer'},
        'required': False,
        'default': 10
    }
]


class BaseView(View):
    URL_PATH: str
    post_request_schema: Schema
    _db = None

    @property
    def pg(self) -> PG:
        return self.request.app['pg']

    @property
    def db(self) -> DBService:
        if self._db is None:
            self._db = DBService(self.pg)
        return self._db

    @property
    def page(self) -> int:
        return int(self.request.rel_url.query.get('page', '1'))

    @property
    def per_page(self) -> int:
        return int(self.request.rel_url.query.get('per_page', '10'))

    def validate(self, method='POST'):
        if method == 'POST' and self.post_request_schema:
            result = self.post_request_schema.validate(self.request['data'])
            if result != {}:
                raise ValidationError(message=result)


class BaseParametrizedView(BaseView):
    @property
    def id(self):
        return int(self.request.match_info.get('id'))
