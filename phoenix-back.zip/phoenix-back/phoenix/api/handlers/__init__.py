from .questions import Question, QuestionParametrized
from .programs import Program, ProgramParametrized
from .ages import Age, AgeParametrized
from .ogorodes import Ogorod, OgorodParametrized


HANDLERS = (
    Question, Program, Age, Ogorod, AgeParametrized,
    ProgramParametrized, QuestionParametrized, OgorodParametrized
)
