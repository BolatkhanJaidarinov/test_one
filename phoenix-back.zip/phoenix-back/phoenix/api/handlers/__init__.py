from .questions import Question, QuestionParametrized
from .programs import Program, ProgramParametrized
from .ages import Age, AgeParametrized


HANDLERS = (
    Question, Program, Age, AgeParametrized,
    ProgramParametrized, QuestionParametrized
)
