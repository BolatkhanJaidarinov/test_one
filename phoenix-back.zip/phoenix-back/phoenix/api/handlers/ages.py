from http import HTTPStatus

from aiohttp_apispec import docs, request_schema, response_schema
from aiohttp.web_response import Response

from phoenix.api.schema import (
    AgePostRequestSchema, AgePostResponseSchema,
    AgeGetResponseSchema, AgeViewResponseSchema
)
from aiohttp.web_exceptions import (
    HTTPNotFound,
)

from .base import (
    BaseView, GET_QUERY_PARAMS, BaseParametrizedView
)


class Age(BaseView):
    URL_PATH = r'/ages/'
    post_request_schema = AgePostRequestSchema()

    @docs(summary="Добавить новый возраст", tags=['ages'])
    @request_schema(AgePostRequestSchema())
    @response_schema(AgePostResponseSchema(), code=HTTPStatus.CREATED.value)
    async def post(self):
        self.validate()
        age = await self.db.insert_age(self.request['data'])
        return Response(body={'data': age}, status=HTTPStatus.CREATED)

    @docs(summary="Получить возрасты", tags=['ages'],
          parameters=GET_QUERY_PARAMS)
    @response_schema(AgeGetResponseSchema(), code=HTTPStatus.OK.value)
    async def get(self):
        items = await self.db.get_ages(self.page, self.per_page)
        count = await self.db.count_ages()
        _meta = {
            'page': self.page,
            'per_page': self.per_page,
            'count': count
        }
        return Response(body={'data': {
            '_meta': _meta,
            'items': items
        }}, status=HTTPStatus.OK)


class AgeParametrized(BaseParametrizedView):
    URL_PATH = r'/ages/{id:\d+}'

    @docs(summary="Получить конкретный возраст", tags=['ages'])
    @response_schema(AgeViewResponseSchema(), code=HTTPStatus.OK.value)
    async def get(self):
        age = await self.db.view_age(self.id)
        if not age:
            raise HTTPNotFound()
        return Response(body={'data': age}, status=HTTPStatus.OK)
