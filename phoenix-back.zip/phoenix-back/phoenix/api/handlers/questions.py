from http import HTTPStatus

from aiohttp_apispec import docs, request_schema, response_schema
from aiohttp.web_response import Response

from phoenix.api.schema import (
    QuestionPostRequestSchema, QuestionPostResponseSchema,
    QuestionGetResponseSchema, QuestionViewResponseSchema
)
from aiohttp.web_exceptions import (
    HTTPNotFound,
)


from .base import (
    BaseView, GET_QUERY_PARAMS, BaseParametrizedView
)


class Question(BaseView):
    URL_PATH = r'/questions/'
    post_request_schema = QuestionPostRequestSchema()

    @docs(summary="Добавить новый вопрос", tags=['questions'])
    @request_schema(QuestionPostRequestSchema())
    @response_schema(QuestionPostResponseSchema(),
                     code=HTTPStatus.CREATED.value)
    async def post(self):
        self.validate()
        question = await self.db.insert_question(self.request['data'])
        return Response(body={'data': question}, status=HTTPStatus.CREATED)

    @docs(summary="Получить вопросы", tags=['questions'],
          parameters=GET_QUERY_PARAMS)
    @response_schema(QuestionGetResponseSchema(), code=HTTPStatus.OK.value)
    async def get(self):
        items = await self.db.get_questions(self.page, self.per_page)
        count = await self.db.count_questions()
        _meta = {
            'page': self.page,
            'per_page': self.per_page,
            'count': count
        }
        return Response(body={'data': {
            '_meta': _meta,
            'items': items
        }}, status=HTTPStatus.OK)


class QuestionParametrized(BaseParametrizedView):
    URL_PATH = r'/questions/{id:\d+}'

    @docs(summary="Получить конкретный вопрос", tags=['questions'])
    @response_schema(QuestionViewResponseSchema(), code=HTTPStatus.OK.value)
    async def get(self):
        q = await self.db.view_question(self.id)
        if not q:
            raise HTTPNotFound()
        return Response(body={'data': q}, status=HTTPStatus.OK)
