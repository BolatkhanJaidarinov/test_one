from http import HTTPStatus

from aiohttp_apispec import docs, request_schema, response_schema
from aiohttp.web_response import Response

from phoenix.api.schema import (
    ProgramPostRequestSchema, ProgramPostResponseSchema,
    ProgramGetResponseSchema, ProgramViewResponseSchema
)
from aiohttp.web_exceptions import (
    HTTPNotFound,
)

from .base import (
    BaseView, GET_QUERY_PARAMS, BaseParametrizedView
)


class Program(BaseView):
    URL_PATH = r'/programs/'
    post_request_schema = ProgramPostRequestSchema()

    @docs(summary="Добавить новую программу", tags=['programs'])
    @request_schema(ProgramPostRequestSchema())
    @response_schema(ProgramPostResponseSchema(),
                     code=HTTPStatus.CREATED.value)
    async def post(self):
        self.validate()
        program = await self.db.insert_program(self.request['data'])
        return Response(body={'data': program}, status=HTTPStatus.CREATED)

    @docs(summary="Получить программы", tags=['programs'],
          parameters=GET_QUERY_PARAMS)
    @response_schema(ProgramGetResponseSchema(), code=HTTPStatus.OK.value)
    async def get(self):
        items = await self.db.get_programs(self.page, self.per_page)
        count = await self.db.count_programs()
        _meta = {
            'page': self.page,
            'per_page': self.per_page,
            'count': count
        }
        return Response(body={'data': {
            '_meta': _meta,
            'items': items
        }}, status=HTTPStatus.OK)


class ProgramParametrized(BaseParametrizedView):
    URL_PATH = r'/programs/{id:\d+}'

    @docs(summary="Получить конкретную программу", tags=['programs'])
    @response_schema(ProgramViewResponseSchema(), code=HTTPStatus.OK.value)
    async def get(self):
        p = await self.db.view_program(self.id)
        if not p:
            raise HTTPNotFound()
        return Response(body={'data': p}, status=HTTPStatus.OK)
