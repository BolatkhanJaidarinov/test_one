from http import HTTPStatus

from aiohttp_apispec import docs, request_schema, response_schema
from aiohttp.web_response import Response

from phoenix.api.schema import (
    OgorodPostRequestSchema, OgorodPostResponseSchema,
    OgorodGetResponseSchema, OgorodViewResponseSchema
)
from aiohttp.web_exceptions import (
    HTTPNotFound,
)

from .base import (
    BaseView, GET_QUERY_PARAMS, BaseParametrizedView
)


class Ogorod(BaseView):
    URL_PATH = r'/ogorodes/'
    post_request_schema = OgorodPostRequestSchema()

    @docs(summary="Добавить новую ogorod программу", tags=['ogorodes'])
    @request_schema(OgorodPostRequestSchema())
    @response_schema(OgorodPostResponseSchema(),
                     code=HTTPStatus.CREATED.value)
    async def post(self):
        self.validate()
        ogorod = await self.db.insert_ogorod(self.request['data'])
        return Response(body={'data': ogorod}, status=HTTPStatus.CREATED)

    @docs(summary="Получить ogorod программы", tags=['ogorodes'],
          parameters=GET_QUERY_PARAMS)
    @response_schema(OgorodGetResponseSchema(), code=HTTPStatus.OK.value)
    async def get(self):
        items = await self.db.get_ogorodes(self.page, self.per_page)
        count = await self.db.count_ogorodes()
        _meta = {
            'page': self.page,
            'per_page': self.per_page,
            'count': count
        }
        return Response(body={'data': {
            '_meta': _meta,
            'items': items
        }}, status=HTTPStatus.OK)


class OgorodParametrized(BaseParametrizedView):
    URL_PATH = r'/ogorodes/{id:\d+}'

    @docs(summary="Получить конкретную ogorod", tags=['ogorodes'])
    @response_schema(OgorodViewResponseSchema(), code=HTTPStatus.OK.value)
    async def get(self):
        g = await self.db.view_ogorod(self.id)
        if not g:
            raise HTTPNotFound()
        return Response(body={'data': g}, status=HTTPStatus.OK)
