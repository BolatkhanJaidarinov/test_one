from hashlib import sha256
from typing import Dict, Any

from sqlalchemy import select, func, literal_column
from asyncpgsa import PG
from marshmallow import ValidationError

from phoenix.db.schema import (
    idempotency_keys_table, ages_table, programs_table,
    questions_table
)


def _generate_idempotency(obj: Dict[str, Any]):
    keys = sorted(obj.keys())
    strings = [f'{key}:{obj[key]}' for key in keys]
    m = sha256()
    for s in strings:
        m.update(s.encode())
    return m.digest().hex()


class DBService:
    def __init__(self, db: PG):
        self._db = db

    async def _check_idempotency_key(self, key):
        query = select([
            func.count()
        ]).where(
            idempotency_keys_table.c.key == key
        )
        return not await self._db.fetchval(query)

    async def _insert(self, table, data):
        key = _generate_idempotency(data)
        if not await self._check_idempotency_key(key):
            raise ValidationError('Idempotency key not unique')

        async with self._db.transaction() as conn:
            query = idempotency_keys_table.insert().values(key=key)
            await conn.execute(query)

            query = table.insert().values(data).returning(literal_column('*'))
            return await conn.fetchrow(query)

    async def insert_question(self, data):
        return await self._insert(questions_table, data)

    async def insert_age(self, data):
        return await self._insert(ages_table, data)

    async def insert_program(self, data):
        return await self._insert(programs_table, data)

    async def _get(self, table, page: int, count_per_page: int):
        offset = (page - 1) * count_per_page
        query = select([
            table
        ]).limit(
            count_per_page
        ).offset(
            offset
        )
        return await self._db.fetch(query)

    async def get_ages(self, page: int, count_per_page: int):
        return await self._get(ages_table, page, count_per_page)

    async def get_programs(self, page: int, per_page: int):
        return await self._get(programs_table, page, per_page)

    async def get_questions(self, page: int, per_page: int):
        return await self._get(questions_table, page, per_page)

    async def _view(self, table, id_: int):
        query = select([
            table
        ]).where(
            table.c.id == id_
        )
        return await self._db.fetchrow(query)

    async def view_age(self, age_id: int):
        return await self._view(ages_table, age_id)

    async def view_program(self, program_id: int):
        return await self._view(programs_table, program_id)

    async def view_question(self, id_: int):
        return await self._view(questions_table, id_)

    async def _count(self, table):
        query = select([
            func.count()
        ]).select_from(
            table
        )
        return await self._db.fetchval(query)

    async def count_ages(self) -> int:
        return await self._count(ages_table)

    async def count_programs(self) -> int:
        return await self._count(programs_table)

    async def count_questions(self) -> int:
        return await self._count(questions_table)
