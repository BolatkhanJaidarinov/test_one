"""
Модуль содержит схемы для валидации данных в запросах и ответах.

Схемы валидации запросов используются в бою для валидации данных отправленных
клиентами.

Схемы валидации ответов *ResponseSchema используются только при тестировании,
чтобы убедиться что обработчики возвращают данные в корректном формате.
"""

from marshmallow import Schema, validates_schema, ValidationError
from marshmallow.fields import Dict, Nested, Str, Int, Boolean, DateTime
from marshmallow.validate import OneOf, Range, Length

from phoenix.utils.pg import MAX_INTEGER
from phoenix.db.schema import QuestionTypes


DATE_FORMAT = '%d.%m.%Y'
DATE_TIME_FORMAT = '%Y-%m-%dT%H:%M:%S'
positive_validator = Range(min=1, max=MAX_INTEGER)


class ErrorSchema(Schema):
    code = Str(required=True)
    message = Str(required=True)
    fields = Dict()


class ErrorResponseSchema(Schema):
    error = Nested(ErrorSchema(), required=True)


class QuestionPostRequestSchema(Schema):
    type = Str(required=True,
               validate=OneOf([t.value for t in QuestionTypes]))
    program_id = Int(required=True, strict=True,
                     validate=positive_validator)
    age_id = Int(required=True, strict=True,
                 validate=positive_validator)
    image = Str(required=False, validate=Length(max=256))
    video = Str(required=False, validate=Length(max=256))
    audio = Str(required=False, validate=Length(max=256))
    text = Str(required=False, validate=Length(max=512))
    answer = Str(required=True, validate=Length(min=1, max=512))

    @validates_schema
    def text_empty(self, data, **_):
        if data['type'] in [QuestionTypes.some_variants,
                            QuestionTypes.type_text] \
                            and not data.get('text'):
            raise ValidationError(
                f'For type "{data["type"]}" field text is required'
            )


class QuestionPostDataResponseSchema(QuestionPostRequestSchema):
    id = Int(required=True, strict=True, validate=positive_validator)
    is_active = Boolean()
    created_at = DateTime(required=True, format=DATE_TIME_FORMAT)
    updated_at = DateTime(required=True, format=DATE_TIME_FORMAT)


class QuestionPostResponseSchema(Schema):
    data = Nested(QuestionPostDataResponseSchema(many=False),
                  required=True)


class ProgramPostRequestSchema(Schema):
    name = Str(required=True, validate=Length(min=10, max=256))


class ProgramPostDataResponseSchema(ProgramPostRequestSchema):
    id = Int(required=True, strict=True, validate=positive_validator)
    is_active = Boolean()
    created_at = DateTime(required=True, format=DATE_TIME_FORMAT)
    updated_at = DateTime(required=True, format=DATE_TIME_FORMAT)


class ProgramPostResponseSchema(Schema):
    data = Nested(ProgramPostDataResponseSchema(many=False), required=True)


class AgePostRequestSchema(Schema):
    from_age = Int(required=False, strict=True,
                   validate=Range(max=100))
    to_age = Int(required=False, strict=True,
                 validate=Range(max=100))
    name = Str(required=True, validate=Length(min=1, max=256))

    @validates_schema
    def to_more_from(self, data, **_):
        to_age = data.get('to_age', 100)
        from_age = data.get('from_age', 0)
        if to_age < from_age:
            raise ValidationError(
                f'From ({data["from_age"]}) should be more '
                f'To ({data["to_age"]}'
            )


class AgePostDataResponseSchema(AgePostRequestSchema):
    id = Int(required=True, strict=True, validate=positive_validator)
    created_at = DateTime(required=True, format=DATE_TIME_FORMAT)
    updated_at = DateTime(required=True, format=DATE_TIME_FORMAT)


class AgePostResponseSchema(Schema):
    data = Nested(AgePostDataResponseSchema(many=False), required=True)


class ResponseMetaSchema(Schema):
    page = Int(required=True, strict=True,
               validate=Range(min=1))
    per_page = Int(required=False, strict=True,
                   validate=Range(min=1))
    count = Int(required=True, strict=True,
                validate=Range(min=0, max=MAX_INTEGER))


class AgeDataResponseSchema(Schema):
    _meta = Nested(ResponseMetaSchema(many=False), required=True)
    items = Nested(AgePostDataResponseSchema(many=True), required=True)


class AgeGetResponseSchema(Schema):
    data = Nested(AgeDataResponseSchema(many=False), required=True)


class AgeViewResponseSchema(Schema):
    data = Nested(AgePostDataResponseSchema(many=False), required=True)


class ProgramDataResponseSchema(Schema):
    _meta = Nested(ResponseMetaSchema(many=False), required=True)
    items = Nested(ProgramPostDataResponseSchema(many=True), required=True)


class ProgramGetResponseSchema(Schema):
    data = Nested(ProgramDataResponseSchema(many=False), required=True)


class ProgramViewResponseSchema(Schema):
    data = Nested(ProgramPostDataResponseSchema(many=False), required=True)


class QuestionDataResponseSchema(Schema):
    _meta = Nested(ResponseMetaSchema(many=False), required=True)
    items = Nested(QuestionPostDataResponseSchema(many=True), required=True)


class QuestionGetResponseSchema(Schema):
    data = Nested(QuestionDataResponseSchema(many=False), required=True)


class QuestionViewResponseSchema(Schema):
    data = Nested(QuestionPostDataResponseSchema(many=False), required=True)
