from enum import Enum, unique
from sqlalchemy import (
    MetaData, Table, Column, Integer, String, UniqueConstraint,
    ForeignKey, Enum as PgEnum, DateTime, Boolean, CheckConstraint
)
from sqlalchemy.sql import func


@unique
class QuestionTypes(Enum):
    type_text = 'type_text'
    some_variants = 'some_variants'
    build_sentence = 'build_sentence'
    insert_words = 'insert_words'


# SQLAlchemy рекомендует использовать единый формат для генерации названий для
# индексов и внешних ключей.
# https://docs.sqlalchemy.org/en/13/core/constraints.html#configuring-constraint-naming-conventions
convention = {
    'all_column_names': lambda constraint, table: '_'.join([
        column.name for column in constraint.columns.values()
    ]),
    'ix': 'ix__%(table_name)s__%(all_column_names)s',
    'uq': 'uq__%(table_name)s__%(all_column_names)s',
    'ck': 'ck__%(table_name)s__%(constraint_name)s',
    'fk': 'fk__%(table_name)s__%(all_column_names)s__%(referred_table_name)s',
    'pk': 'pk__%(table_name)s'
}

metadata = MetaData(naming_convention=convention)


programs_table = Table(
    'programs',
    metadata,
    Column('id', Integer, primary_key=True, autoincrement=True),
    Column('name', String, nullable=False),
    Column('is_active', Boolean, nullable=False, default=False),
    Column('created_at', DateTime(timezone=True),
           server_default=func.now()),
    Column('updated_at', DateTime(timezone=True),
           onupdate=func.now(),
           server_default=func.now())
)


ages_table = Table(
    'ages',
    metadata,
    Column('id', Integer, primary_key=True, autoincrement=True),
    Column('from_age', Integer, nullable=False, default=0),
    Column('to_age', Integer, nullable=False, default=100),
    Column('name', String, nullable=False),
    Column('created_at', DateTime(timezone=True),
           server_default=func.now()),
    Column('updated_at', DateTime(timezone=True),
           server_default=func.now(),
           onupdate=func.now()),
    UniqueConstraint('from_age', 'to_age'),
    CheckConstraint('from_age <= to_age', name='from_less_to')
)

questions_table = Table(
    'questions',
    metadata,
    Column('id', Integer, primary_key=True, autoincrement=True),
    Column('program_id', Integer, ForeignKey('programs.id'),
           nullable=False),
    Column('age_id', Integer, ForeignKey('ages.id'),
           nullable=False),
    Column('type', PgEnum(QuestionTypes, name='QuestionTypes'),
           nullable=False),
    Column('image', String, nullable=False, default=''),
    Column('video', String, nullable=False, default=''),
    Column('audio', String, nullable=False, default=''),
    Column('text', String, nullable=False, default=''),
    Column('answer', String, nullable=False),
    Column('is_active', Boolean, nullable=False, default=False),
    Column('created_at', DateTime(timezone=True),
           server_default=func.now()),
    Column('updated_at', DateTime(timezone=True),
           onupdate=func.now(),
           server_default=func.now())
)

idempotency_keys_table = Table(
    'idempotency_keys',
    metadata,
    Column('key', String(length=64), nullable=False, primary_key=True)
)
