from fabric.contrib.files import exists
from fabric.api import run


REPO_URL = 'git@github.com:vercity-ru/phoenix-back.git'


def _get_latest_source(site_folder):
    if exists(site_folder + '/.git'):
        run(f'cd {site_folder} && git fetch')
    else:
        run(f'git clone {REPO_URL} {site_folder}')
    run(f'cd {site_folder} && git checkout dev && git reset --hard origin/dev')


def _update_venv(site_folder):
    if not exists(site_folder + '/venv'):
        run(f'cd {site_folder} && virtualenv -p python3.7 venv')
    pip = 'venv/bin/pip'
    run(f'{site_folder}/{pip} install -r {site_folder}/requirements.txt')


def _restart_app():
    run('sudo supervisorctl restart aiohttp:')


def deploy():
    site_folder = '/home/lex/phoenix-back'
    _get_latest_source(site_folder)
    _update_venv(site_folder)
    _restart_app()
